﻿using UnityEngine;
using System.Collections.Generic;
[System.Serializable]
public partial class CameraCont : MonoBehaviour {
	public Transform target;
	public int distance;
	public float lift;
	public virtual void Update()
	{
		this.transform.position = this.target.position + new Vector3(0,
		this.lift, this.distance);
		this.transform.LookAt(this.target);
	}
	public CameraCont()
	{
		this.distance=-10;
		this.lift=1.5f;
	}
	
}
